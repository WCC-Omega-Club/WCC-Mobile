import java.io.*;
import java.util.ArrayList;
import javax.xml.stream.*;

import org.jsoup.*;
import org.jsoup.nodes.*;

/*
Programmer: Brandon Foster
Date Created: March 22, 2016
Program: Course Parser
Version: 1.0.0
Purpose: Parses the Courses listed on the
         SunyWCC's Course Description page (http://catalog.sunywcc.edu/content.php?catoid=31&navoid=3784) into a XML File.
         
         This does not include the Course Number, only the Course ID and Name.
Notes:
   XML File Info
   -------------
   Root element - "majors"
   Each element in the Root element is called "major" with an attribute for the name.
   Each element in a major is called "course" with an attribute for the name and the id.
   
   Req Library
   -----------
   JSoup - For HTML Parsing. Version 1.8.3 or better. http://jsoup.org/download 
*/

public class CourseParser
{
   private static XMLStreamWriter xmlWriter;
   private static ArrayList<Course> courses; 
   
   public static void main(String[] args)
   {
      try
      {
         //Gets WCC's course page html
         Document doc = Jsoup.connect("http://catalog.sunywcc.edu/content.php?catoid=31&navoid=3784").get();
         Element body = doc.body();
         
         //Cuts the html to only include the table for the courses.
			StringBuilder courseSB = new StringBuilder(body.toString());
			courseSB = new StringBuilder(courseSB.substring(courseSB.indexOf("<!-- End advanced search filter. --> ")));
			StringBuilder pageSB = new StringBuilder(courseSB.substring(courseSB.indexOf("<tbody>")+9,courseSB.indexOf("</tbody>")));
			pageSB = new StringBuilder(pageSB.substring(pageSB.indexOf("Page:")));
			pageSB = new StringBuilder(pageSB.substring(pageSB.indexOf("template_course_filter"),pageSB.indexOf("</a></td")));
			pageSB = new StringBuilder(pageSB.substring(pageSB.length()-4));
         
			int maxPage = Integer.parseInt(pageSB.substring(pageSB.indexOf(">")+1)); //Sets the maximum page
         try
         {
            FileOutputStream fos = new FileOutputStream("courses.xml");
            XMLOutputFactory output = XMLOutputFactory.newInstance();
            xmlWriter = output.createXMLStreamWriter(fos,"UTF-8");
            xmlWriter.writeStartDocument("UTF-8","1.0");
            
            //Sets up the courses ArrayList based on the html text.
            courses = new ArrayList<Course>();
            addCourses(courseSB); //Checks the first page.
			   readPages(maxPage); //Checks the remaining pages.
            
            writeMajors(); //Writes the course information to the xmlWriter
            xmlWriter.writeEndDocument();
            xmlWriter.flush();
            
            xmlWriter.close();
            fos.close();
         }
         catch(XMLStreamException ex)
         {
            ex.printStackTrace();
         }
         catch(IOException ex)
         {
            ex.printStackTrace();
         }
         
      }
      catch(IOException ex)
      {
         System.out.println("Cannot parse the courses: " + ex.toString());
      }
   }
	
   /**
    *Reads the courses from the WCC Course Information page from the 2nd to last page.
    */
	public static void readPages(int max)
	{
		for(int i=2;i<=max;i++)
		{
			try
	      {
            //Cuts the html to only include the table for the courses.
	         Document doc = Jsoup.connect("http://catalog.sunywcc.edu/content.php?catoid=31&navoid=3784&filter%5Bcpage%5D="+i+"#acalog_template_course_filter").get();
				StringBuilder courseSB = new StringBuilder(doc.outerHtml());
				courseSB = new StringBuilder(courseSB.substring(courseSB.indexOf("<!-- End advanced search filter. --> ")));
				addCourses(courseSB);
	      }
	      catch(IOException ex)
	      {
	         System.out.println("Cannot parse the courseSB on Page " + i + ": " + ex.toString());
	      }
		}
	}
	
   /**
    *Adds every course found in a page to the courses and displays them.
    */
   public static void addCourses(StringBuilder courseSB)
	{
		int i=0;
		while((i=courseSB.indexOf("preview_course"))!=-1)
		{
         String major;
			String courseName;
			String courseID;
			courseSB = new StringBuilder(courseSB.substring(i+1));
			StringBuilder classSB = new StringBuilder(courseSB.substring(courseSB.indexOf(">")+1,courseSB.indexOf("<")));
			major = classSB.substring(0,classSB.indexOf(" "));
			courseID = classSB.substring(classSB.indexOf(" ")+1,classSB.indexOf("&"));
			courseName = classSB.substring(classSB.indexOf("&")+13).trim().replaceAll("&amp;","&");
			courses.add(new Course(major,courseID,courseName));
         
         System.out.println(major + " " + courseID + " - " + courseName);
      }
   }
   
   /**
    *Writes the courses information based on their majors into the xml file
    */
   public static void writeMajors()
	{
      try
      {
         String major = courses.get(0).getMajor();
         xmlWriter.writeCharacters(String.format("%n"));
         xmlWriter.writeComment("The valid ids and course names for each major.");
         xmlWriter.writeCharacters(String.format("%n"));
         xmlWriter.writeStartElement("majors");
         xmlWriter.writeCharacters(String.format("%n  "));
         xmlWriter.writeStartElement("major");
         xmlWriter.writeAttribute("name",major);
   		for(Course course: courses)
   		{
            if(!major.equals(course.getMajor()))
            {
               major = course.getMajor();
               
               xmlWriter.writeCharacters(String.format("%n  "));
               xmlWriter.writeEndElement();
               xmlWriter.writeCharacters(String.format("%n  "));
               xmlWriter.writeStartElement("major");
               xmlWriter.writeAttribute("name",major);
            }
            try
            {
               xmlWriter.writeCharacters(String.format("%n     "));
               xmlWriter.writeEmptyElement("course");
               xmlWriter.writeAttribute("id",course.getID());  
               xmlWriter.writeAttribute("name",course.getName());           
            }
            catch(XMLStreamException ex)
            {
               ex.printStackTrace();
            }
         }
         xmlWriter.writeCharacters(String.format("%n  "));
         xmlWriter.writeEndElement();
         xmlWriter.writeCharacters(String.format("%n"));
         xmlWriter.writeEndElement();
		}
      catch(XMLStreamException ex)
      {
         ex.printStackTrace();
      }
	}
}