public class Course
{
   private String major;
   private String id;
   private String name;
   private String location;
   
   public Course()
   {
   }
   
   public Course(String major, String id, String name)
   {
      this();
      this.major = major;
      this.id = id;
      this.name = name;
   }
   
   public void setMajor(String major)
   {
      this.major = major;
   }
   
   public void setID(String id)
   {
      this.id = id;
   }
   
   public void setName(String name)
   {
      this.name = name;
   }
   
   public void setLocation(String location)
   {
      this.location = location;
   }
   
   public String getMajor()
   {
      return major;
   }
   
   public String getID()
   {
      return id;
   }
   
   public String getName()
   {
      return name;
   }
   
   public String getLocation()
   {
      return location;
   }
}