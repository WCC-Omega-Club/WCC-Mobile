import java.util.*;
import java.io.*;
import javax.xml.stream.*;

public class CourseReader
{
   private static HashMap<String,ArrayList<String>> majorIDMap; //Hashmap where the keys are the majors and the values are an ArrayList of course ids.
   private static HashMap<String,ArrayList<String>> majorNameMap; //Hashmap where the keys are the majors and the values are an ArrayList of course names.
   private static ArrayList<String> majors; //An ArrayList of the majors.
   private static ArrayList<String> courseLocations; //An ArrayList of the course locations.
   
   public static void main(String[] args)
   {
      //Demo
      createInfo();
      
      for(String m: getMajors())
      {
         ArrayList<String> ids = getCourseIDs(m);
         ArrayList<String> names = getCourseNames(m);
         int i = 0;
         for(String n: names)
         {
            System.out.println(m + " - " + ids.get(i) + " - " + n);
            i++;
         }
      }
   }
   
   public static void createInfo()
   {
      createLocations();
      XML2Maps();
   }
   
   private static void createLocations()
   {
      courseLocations = new ArrayList<String>();
      courseLocations.add("Academics Art Bldg");
      courseLocations.add("Classroom Bldg");
      courseLocations.add("Health Science Bldg");
      courseLocations.add("Library");
      courseLocations.add("Physical Education Bldg");
      courseLocations.add("Science Bldg");
      courseLocations.add("Technology Bldg");
   }
   
   /**
    *Reads the majors from the xml file and sets the information into the hashmaps.
    */
   private static void XML2Maps()
   {
      try
      {
         FileInputStream fis = new FileInputStream("courses.xml");
         XMLInputFactory input = XMLInputFactory.newInstance();
         XMLStreamReader xmlReader = input.createXMLStreamReader(fis);
         int scope = 0;
         String mainElement=null;
         
         majorIDMap = new HashMap<String,ArrayList<String>>();
         majorNameMap = new HashMap<String,ArrayList<String>>();
         majors = new ArrayList<String>();
         
         String currentMajor=null;
         while(xmlReader.hasNext())
         {
            xmlReader.nextTag();
            if(xmlReader.isStartElement())
            {
               switch(xmlReader.getName().toString())
               {
                  case "major":
                     currentMajor = xmlReader.getAttributeValue(0);
                     majorIDMap.put(currentMajor,new ArrayList<String>());
                     majorNameMap.put(currentMajor,new ArrayList<String>());
                     majors.add(currentMajor);
                     break;
                  case "course":
                     majorIDMap.get(currentMajor).add(xmlReader.getAttributeValue(0));
                     majorNameMap.get(currentMajor).add(xmlReader.getAttributeValue(1));
                     break;
               }
            } 
         }
         
         xmlReader.close();
         fis.close();
      }
      catch(XMLStreamException ex)
      {
         ex.printStackTrace();
      }
      catch(IOException ex)
      {
         ex.printStackTrace();
      }
   }
   
   public static ArrayList<String> getMajors()
   {
      return majors;
   }
   
   public static ArrayList<String> getCourseIDs(String major)
   {
      return majorIDMap.get(major);
   }
   
   public static ArrayList<String> getCourseNames(String major)
   {
      return majorNameMap.get(major);
   }
   
   public static ArrayList<String> getCourseLocations()
   {
      return courseLocations;
   }
}